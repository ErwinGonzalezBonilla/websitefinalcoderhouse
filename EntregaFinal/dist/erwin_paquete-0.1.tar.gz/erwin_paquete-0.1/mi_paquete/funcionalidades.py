from datetime import datetime

def mostrar_fecha():
    print(datetime.now())
    