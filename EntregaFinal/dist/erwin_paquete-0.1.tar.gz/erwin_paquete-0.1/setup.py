from setuptools import setup 
setup(
    name='erwin_paquete',
    version='0.1',
    author='Erwin',
    author_email='alexcultural@gmail.com',
    description=' este es mi paquete',
    packages=['mi_paquete'],
)